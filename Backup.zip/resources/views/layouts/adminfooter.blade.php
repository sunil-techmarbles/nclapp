<div id="footer">
	<p class="text-center p-10"><b>{{ config('app.name') }}</b> Copyrights @ @php echo date('Y') @endphp</p>
</div>